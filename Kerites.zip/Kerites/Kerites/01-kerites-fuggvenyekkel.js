

const prompt = require('prompt-sync')()

function kerites_hossz_kalkulator(oszlopok_tomb) {
    keriteshossz = 0
    for (b = 0; b < oszlopok_tomb.length; b++) {
        console.log("A bevitt oszlopok koordinátái:")
        for (b = 0; b < oszlopok_tomb.length; b++) {
            console.log((b + 1) + ". oszlop: " + oszlopok_tomb[b][0] + ":" + oszlopok_tomb[b][1])
        }
        for (b = 0; b < oszlopok_tomb.length; b++) {
            if (b != oszlopok_tomb.length - 1) {
                a_oldal = oszlopok_tomb[b][0] - oszlopok_tomb[b + 1][0]
                b_oldal = oszlopok_tomb[b][1] - oszlopok_tomb[b + 1][1]
            } else { 
                a_oldal = oszlopok_tomb[b][0] - oszlopok_tomb[0][0]
                b_oldal = oszlopok_tomb[b][1] - oszlopok_tomb[0][1]
            }
            c_oldal = Math.sqrt(Math.pow(a_oldal, 2) + Math.pow(b_oldal, 2)) 
            keriteshossz += c_oldal
        }

    }
    return keriteshossz
}

oszlopok_szama = prompt("Kérem a kerítés oszlopainak számát! ") 
var oszlopok = [] 
for (b = 0; b < oszlopok_szama; b++) {
    var oszlop = [] 
    oszlop[0] = prompt("Kérem a " + (b + 1) + ". oszlop x koordinátáját! ")
    oszlop[1] = prompt("Kérem a " + (b + 1) + ". oszlop y koordinátáját! ")
    oszlopok.push(oszlop)
}

console.log("A kerítés hossza: " + kerites_hossz_kalkulator(oszlopok))