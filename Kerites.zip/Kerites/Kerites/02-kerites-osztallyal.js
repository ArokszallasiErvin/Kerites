

const prompt = require('prompt-sync')()

class kerites_hossz_kalkulator {
    constructor() {
        this.oszlopok_szama = prompt("Kérem a kerítés oszlopainak számát! ") 
        this.oszlopok = [] 
        for (var b = 0; b < this.oszlopok_szama; b++) {
            var oszlop = []
            oszlop[0] = prompt("Kérem a " + (b + 1) + ". oszlop x koordinátáját! ")
            oszlop[1] = prompt("Kérem a " + (b + 1) + ". oszlop y koordinátáját! ")
            this.oszlopok.push(oszlop)
        }
    }
    oszlopok_listazasa() {
        for (var b = 0; b < this.oszlopok_szama; b++) {
            console.log("A bevitt oszlopok koordinátái:")
            for (var b = 0; b < this.oszlopok_szama; b++) {
                console.log((b + 1) + ". oszlop:  " + this.oszlopok[b][0] + ":" + this.oszlopok[b][1])
            }
        }
    }
    hossz_szamitas() {
        var keriteshossz = 0
        var a_oldal = 0
        var b_oldal = 0
        var c_oldal = 0
        for (var b = 0; b < this.oszlopok_szama; b++) {
            if (b != this.oszlopok_szama - 1) { 
                a_oldal = this.oszlopok[b][0] - this.oszlopok[b + 1][0]
                b_oldal = this.oszlopok[b][1] - this.oszlopok[b + 1][1]
            } else { 
                a_oldal = this.oszlopok[b][0] - this.oszlopok[0][0]
                b_oldal = this.oszlopok[b][1] - this.oszlopok[0][1]
            }
            c_oldal = Math.sqrt(Math.pow(a_oldal, 2) + Math.pow(b_oldal, 2)) 
            keriteshossz += c_oldal
        }
        return keriteshossz
    }
}

kerites1 = new kerites_hossz_kalkulator()

kerites1.oszlopok_listazasa()
console.log("A kerítés hossza: " + kerites1.hossz_szamitas())